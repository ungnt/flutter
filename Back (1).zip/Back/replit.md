# REGRAS DO USUÁRIO - OBRIGATÓRIAS PARA TODOS OS AGENTES

1. **Seja direto e objetivo** - Responda de forma breve. Quando possível, use apenas "Sim" ou "Não"

2. **Faça apenas o que foi pedido** - Nada além do solicitado

3. **Não faça nada além do que foi pedido** - Sem iniciativas extras

4. **Em caso de dúvida, pergunte** - Sempre pare e pergunte, mesmo que ache que entendeu

5. **Flutter não roda aqui** - Projetos Flutter NÃO podem ser executados no Replit. Build é feito via Codemagic (usuário faz via `git add .` e `git push`)

6. **Backend roda aqui** - Backend Dart/Shelf executa no Replit para análise e testes com banco de dados

7. **SUPABASE NÃO VAI SER USADO** - usar banco de dados no backend 








