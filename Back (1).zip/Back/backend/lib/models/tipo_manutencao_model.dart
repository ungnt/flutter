class TipoManutencaoModel {
  final String? id;
  final String userId;
  final String nome;
  final DateTime createdAt;

  TipoManutencaoModel({
    this.id,
    required this.userId,
    required this.nome,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() {
    final map = {
      'user_id': userId,
      'nome': nome,
      'created_at': createdAt.toIso8601String(),
    };
    
    if (id != null) map['id'] = id;
    
    return map;
  }

  factory TipoManutencaoModel.fromJson(Map<String, dynamic> json) {
    return TipoManutencaoModel(
      id: json['id']?.toString(),
      userId: json['user_id']?.toString() ?? '',
      nome: json['nome']?.toString() ?? '',
      createdAt: json['created_at'] != null 
        ? DateTime.parse(json['created_at']) 
        : DateTime.now(),
    );
  }

  @override
  String toString() {
    return 'TipoManutencaoModel(id: $id, userId: $userId, nome: $nome)';
  }
}
