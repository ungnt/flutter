class IntervaloManutencaoModel {
  final String? id;
  final String userId;
  final String tipoManutencao;
  final double kmIntervalo;
  final DateTime createdAt;
  final DateTime updatedAt;

  IntervaloManutencaoModel({
    this.id,
    required this.userId,
    required this.tipoManutencao,
    required this.kmIntervalo,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() {
    final map = {
      'user_id': userId,
      'tipo_manutencao': tipoManutencao,
      'km_intervalo': kmIntervalo,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
    
    if (id != null) map['id'] = id;
    
    return map;
  }

  factory IntervaloManutencaoModel.fromJson(Map<String, dynamic> json) {
    return IntervaloManutencaoModel(
      id: json['id']?.toString(),
      userId: json['user_id']?.toString() ?? '',
      tipoManutencao: json['tipo_manutencao']?.toString() ?? '',
      kmIntervalo: (json['km_intervalo'] as num?)?.toDouble() ?? 0.0,
      createdAt: json['created_at'] != null 
        ? DateTime.parse(json['created_at']) 
        : DateTime.now(),
      updatedAt: json['updated_at'] != null 
        ? DateTime.parse(json['updated_at']) 
        : DateTime.now(),
    );
  }

  @override
  String toString() {
    return 'IntervaloManutencaoModel(id: $id, userId: $userId, tipoManutencao: $tipoManutencao, kmIntervalo: $kmIntervalo)';
  }
}
