import 'dart:convert';
import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';
import '../services/database_service.dart';
import '../services/auth_service.dart';

class TiposManutencaoRoutes {
  final DatabaseService _databaseService;
  final AuthService _authService;

  TiposManutencaoRoutes(this._databaseService, this._authService);

  Router get router {
    final router = Router()
      ..post('/', _createTipoManutencao)
      ..get('/', _getTiposManutencao)
      ..delete('/<id>', _deleteTipoManutencao);
    
    return router;
  }

  Future<Response> _createTipoManutencao(Request request) async {
    try {
      final userId = await _getUserFromToken(request);
      if (userId == null) {
        return Response.unauthorized(
          jsonEncode({'success': false, 'message': 'Não autorizado'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      final body = await request.readAsString();
      final data = jsonDecode(body) as Map<String, dynamic>;

      if (data['nome'] == null || data['nome'].toString().trim().isEmpty) {
        return Response.badRequest(
          body: jsonEncode({'success': false, 'message': 'Nome do tipo de manutenção é obrigatório'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      final nome = data['nome'].toString().trim();
      final id = await _databaseService.createTipoManutencao(userId, nome);

      return Response.ok(
        jsonEncode({
          'success': true,
          'message': 'Tipo de manutenção criado com sucesso',
          'data': {
            'id': id,
            'user_id': userId,
            'nome': nome,
          },
        }),
        headers: {'Content-Type': 'application/json'},
      );
    } catch (e) {
      if (e.toString().contains('UNIQUE constraint failed')) {
        return Response(409,
          body: jsonEncode({
            'success': false,
            'message': 'Tipo de manutenção já existe',
          }),
          headers: {'Content-Type': 'application/json'},
        );
      }
      return Response.internalServerError(
        body: jsonEncode({
          'success': false,
          'message': 'Erro ao criar tipo de manutenção: $e',
        }),
        headers: {'Content-Type': 'application/json'},
      );
    }
  }

  Future<Response> _getTiposManutencao(Request request) async {
    try {
      final userId = await _getUserFromToken(request);
      if (userId == null) {
        return Response.unauthorized(
          jsonEncode({'success': false, 'message': 'Não autorizado'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      final tiposManutencao = _databaseService.getTiposManutencaoByUser(userId);

      return Response.ok(
        jsonEncode({
          'success': true,
          'data': {'tipos_manutencao': tiposManutencao},
        }),
        headers: {'Content-Type': 'application/json'},
      );
    } catch (e) {
      return Response.internalServerError(
        body: jsonEncode({
          'success': false,
          'message': 'Erro ao buscar tipos de manutenção: $e',
        }),
        headers: {'Content-Type': 'application/json'},
      );
    }
  }

  Future<Response> _deleteTipoManutencao(Request request) async {
    try {
      final userId = await _getUserFromToken(request);
      if (userId == null) {
        return Response.unauthorized(
          jsonEncode({'success': false, 'message': 'Não autorizado'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      final id = request.params['id'];
      if (id == null) {
        return Response.badRequest(
          body: jsonEncode({'success': false, 'message': 'ID não fornecido'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      final affectedRows = _databaseService.deleteTipoManutencao(id, userId);

      if (affectedRows == 0) {
        return Response.notFound(
          jsonEncode({'success': false, 'message': 'Tipo de manutenção não encontrado'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      return Response.ok(
        jsonEncode({
          'success': true,
          'message': 'Tipo de manutenção deletado com sucesso',
        }),
        headers: {'Content-Type': 'application/json'},
      );
    } catch (e) {
      return Response.internalServerError(
        body: jsonEncode({
          'success': false,
          'message': 'Erro ao deletar tipo de manutenção: $e',
        }),
        headers: {'Content-Type': 'application/json'},
      );
    }
  }

  Future<String?> _getUserFromToken(Request request) async {
    final token = request.headers['authorization']?.replaceFirst('Bearer ', '');
    if (token == null) return null;

    try {
      final payload = _authService.validateJWT(token);
      return payload?['user_id'];
    } catch (e) {
      return null;
    }
  }
}
