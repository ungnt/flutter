import 'dart:convert';
import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';
import '../services/database_service.dart';
import '../services/auth_service.dart';

class IntervalosManutencaoRoutes {
  final DatabaseService _databaseService;
  final AuthService _authService;

  IntervalosManutencaoRoutes(this._databaseService, this._authService);

  Router get router {
    final router = Router()
      ..put('/', _createOrUpdateIntervalo)
      ..get('/', _getIntervalos)
      ..delete('/<id>', _deleteIntervalo);
    
    return router;
  }

  Future<Response> _createOrUpdateIntervalo(Request request) async {
    try {
      final userId = await _getUserFromToken(request);
      if (userId == null) {
        return Response.unauthorized(
          jsonEncode({'success': false, 'message': 'Não autorizado'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      final body = await request.readAsString();
      final data = jsonDecode(body) as Map<String, dynamic>;

      if (data['tipo_manutencao'] == null || data['tipo_manutencao'].toString().trim().isEmpty) {
        return Response.badRequest(
          body: jsonEncode({'success': false, 'message': 'Tipo de manutenção é obrigatório'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      if (data['km_intervalo'] == null) {
        return Response.badRequest(
          body: jsonEncode({'success': false, 'message': 'Intervalo em KM é obrigatório'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      final tipoManutencao = data['tipo_manutencao'].toString().trim();
      final kmIntervalo = (data['km_intervalo'] as num).toDouble();

      final id = await _databaseService.createOrUpdateIntervaloManutencao(
        userId, 
        tipoManutencao, 
        kmIntervalo
      );

      return Response.ok(
        jsonEncode({
          'success': true,
          'message': 'Intervalo de manutenção salvo com sucesso',
          'data': {
            'id': id,
            'user_id': userId,
            'tipo_manutencao': tipoManutencao,
            'km_intervalo': kmIntervalo,
          },
        }),
        headers: {'Content-Type': 'application/json'},
      );
    } catch (e) {
      return Response.internalServerError(
        body: jsonEncode({
          'success': false,
          'message': 'Erro ao salvar intervalo de manutenção: $e',
        }),
        headers: {'Content-Type': 'application/json'},
      );
    }
  }

  Future<Response> _getIntervalos(Request request) async {
    try {
      final userId = await _getUserFromToken(request);
      if (userId == null) {
        return Response.unauthorized(
          jsonEncode({'success': false, 'message': 'Não autorizado'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      final intervalos = _databaseService.getIntervalosManutencaoByUser(userId);

      return Response.ok(
        jsonEncode({
          'success': true,
          'data': {'intervalos_manutencao': intervalos},
        }),
        headers: {'Content-Type': 'application/json'},
      );
    } catch (e) {
      return Response.internalServerError(
        body: jsonEncode({
          'success': false,
          'message': 'Erro ao buscar intervalos de manutenção: $e',
        }),
        headers: {'Content-Type': 'application/json'},
      );
    }
  }

  Future<Response> _deleteIntervalo(Request request) async {
    try {
      final userId = await _getUserFromToken(request);
      if (userId == null) {
        return Response.unauthorized(
          jsonEncode({'success': false, 'message': 'Não autorizado'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      final id = request.params['id'];
      if (id == null) {
        return Response.badRequest(
          body: jsonEncode({'success': false, 'message': 'ID não fornecido'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      final affectedRows = _databaseService.deleteIntervaloManutencao(id, userId);

      if (affectedRows == 0) {
        return Response.notFound(
          jsonEncode({'success': false, 'message': 'Intervalo de manutenção não encontrado'}),
          headers: {'Content-Type': 'application/json'},
        );
      }

      return Response.ok(
        jsonEncode({
          'success': true,
          'message': 'Intervalo de manutenção deletado com sucesso',
        }),
        headers: {'Content-Type': 'application/json'},
      );
    } catch (e) {
      return Response.internalServerError(
        body: jsonEncode({
          'success': false,
          'message': 'Erro ao deletar intervalo de manutenção: $e',
        }),
        headers: {'Content-Type': 'application/json'},
      );
    }
  }

  Future<String?> _getUserFromToken(Request request) async {
    final token = request.headers['authorization']?.replaceFirst('Bearer ', '');
    if (token == null) return null;

    try {
      final payload = _authService.validateJWT(token);
      return payload?['user_id'];
    } catch (e) {
      return null;
    }
  }
}
